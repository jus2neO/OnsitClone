export const countries = [
    {
      image: "/images/image-1.jpg",
      title: "SIT 1",
    },
    {
      image: "/images/image-2.jpg",
      title: "SIT 2",
    },
    {
      image: "/images/image-3.jpg",
      title: "COE (SIT 1, 2, 3)",
    },
 
  ];