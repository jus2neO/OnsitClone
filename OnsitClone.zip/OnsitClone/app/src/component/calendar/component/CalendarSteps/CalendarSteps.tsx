import React from "react";
import CustomCalendar from "../CustomCalendar/CustomCalendar";

export default function CalendarSteps() {
  return (
    <div>
      <CustomCalendar />
    </div>
  );
}
