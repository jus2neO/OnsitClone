import "./aboutus.css";
import ImgHero from "./images/aboutus.png";


function App() {
  return (
    
    <section className="back" style={{ backgroundImage: `url(${ImgHero})` }}>
    </section>
  );
}

export default App;