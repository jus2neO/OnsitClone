import React from 'react';
import "./activityoverview.scss";

const activityoverview = () => {
  return (
    <div>activityoverview</div>
  )
}

export default activityoverview;