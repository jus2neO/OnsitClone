import React from 'react';

const nopage = () => {
  return (
    <div>
        <h1>No page</h1>
    </div>
  )
}

export default nopage;