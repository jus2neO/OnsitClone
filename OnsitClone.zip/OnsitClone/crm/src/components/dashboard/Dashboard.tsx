import "./dashboard.scss";
import ImgHero from "./images/banner.png";


function App() {
  return (
    
    <section className="back" style={{ backgroundImage: `url(${ImgHero})` }}>
    </section>
  );
}

export default App;