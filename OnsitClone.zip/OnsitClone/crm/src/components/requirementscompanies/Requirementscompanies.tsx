import React from 'react';

const Requirementscompanies = () => {
  return (
    <div>requirementscompanies</div>
  )
}

export default Requirementscompanies;