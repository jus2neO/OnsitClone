import {useEffect, useState} from 'react';
import {addRoleLevel, getAllRole, updateRoleLevel} from "../services/roleServices";
import "./role.scss";

const Role = () => {
  return (
    <section>Role</section>
  )
}

export default Role;