const Model = require('./model.js');
module.exports =  new class AppointmentFileModel extends Model {

    constructor(){
        super('appointmentfile');
    }

}