const Model = require('./model.js');
module.exports =  new class CompanyCoursePreferModel extends Model {

    constructor(){
        super('companycourseprefer');
    }

}