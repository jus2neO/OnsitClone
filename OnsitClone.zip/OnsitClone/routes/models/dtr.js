const Model = require('./model.js');
module.exports =  new class DTRModel extends Model {

    constructor(){
        super('dtr');
    }

}