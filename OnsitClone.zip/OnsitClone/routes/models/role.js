const Model = require('./model.js');
module.exports =  new class RoleModel extends Model {

    constructor(){
        super('role');
    }

}