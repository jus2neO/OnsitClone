const Model = require('./model.js');
module.exports =  new class schedulesettingsModel extends Model {

    constructor(){
        super('schedulesettings');
    }

}