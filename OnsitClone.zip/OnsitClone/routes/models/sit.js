const Model = require('./model.js');
module.exports =  new class SITModel extends Model {

    constructor(){
        super('sitlevel');
    }

}