const Model = require('./model.js');
module.exports =  new class SITRequirementModel extends Model {

    constructor(){
        super('sitrequirements');
    }

}