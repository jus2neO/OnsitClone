const Model = require('./model.js');
module.exports =  new class StudentSITCompanyArchieveModel extends Model {

    constructor(){
        super('studentsitcompanyarchieve');
    }

}
