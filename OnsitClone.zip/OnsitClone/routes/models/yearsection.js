const Model = require('./model.js');
module.exports =  new class YearSectionModel extends Model {

    constructor(){
        super('yearsection');
    }

}